# Android Updater Demo (safe starter)

This starter checks a hosted JSON manifest and, when a newer version exists, displays its release notes and opens your **official update webpage** in the browser. It does not silently install apps or launch an APK installer. This keeps the update flow transparent and lets users review the app and download source.


## 1. Open and build
1. Install Android Studio on a computer (the simplest reliable build path). Create/open this folder as a Gradle project.
2. Wait for Gradle sync. If prompted, install Android SDK Platform 35 and a compatible build-tools package.
3. In `MainActivity.kt`, replace `https://YOUR-DOMAIN.example/update.json` with your HTTPS manifest URL.
4. In `server/update.json`, set the update page URL to your real HTTPS page.
5. Build > Build APK(s), then install the debug APK on your own device.


## 2. Host the PHP API and JSON
Upload the `server/` directory contents to a PHP-enabled HTTPS host. Example URLs:
- `https://your-domain.example/update.json`
- `https://your-domain.example/index.php`

You can point the app to `index.php` instead of `update.json` if you want PHP to serve the manifest. The sample app currently fetches JSON directly; use `index.php` as the URL if hosted.


## 3. Release a same-app update
- Keep `applicationId` (`com.example.updaterdemo`) unchanged.
- Increase `versionCode` in `app/build.gradle` for every release; update `versionName` too.
- Build and sign release APK with the **same signing key** used for the previous release.
- Host an official update page with the release APK and its change notes.
- Update `server/update.json` with the latest `versionCode`, `versionName`, notes and update page URL.
- Users should install updates only from your official trusted source and review Android's installer prompt.

**Important:** Android updates to an existing app require the same package/application ID and a compatible signing certificate. Changing either can prevent an update and may require uninstalling (which can delete app data).

## 4. Android phone-only note
This project can be edited on a phone, but building a native Android APK on phone is more complicated and may require a supported mobile IDE or a carefully configured command-line Android SDK/Gradle setup. Android Studio on a computer is the recommended beginner build method.

## 5. Troubleshooting
- `Could not check update`: confirm HTTPS URL, hosting, and valid JSON.
- `You are up to date`: compare manifest `versionCode` to installed app's `versionCode`.
- Never host APKs from unknown sources; use HTTPS and publish checksums/signing information when possible.

## 6. Build using GitHub Actions from a phone (no Android Studio)
1. Create a GitHub repository in your browser and choose **Add file → Upload files**. Upload the project files and folders, including `.github/workflows/android-build.yml` (GitHub may hide dot-folders in some mobile upload pickers; if so, use a Git client or GitHub's web editor to create the workflow file at that exact path).
2. Commit the files to the `main` branch.
3. Open the repository's **Actions** tab. Select **Build Android APK** and press **Run workflow** (or push a commit to `main` to trigger it).
4. Wait for the workflow to finish with a green check.
5. Open the completed workflow run, scroll to **Artifacts**, and download `AndroidUpdaterDemo-debug-apk`.
6. Extract the artifact ZIP and install the APK on your phone. Android may ask you to allow installing apps from the browser/file manager you used; only enable this for the trusted app and turn it off again afterward if you prefer.

The workflow builds a **debug APK** for testing. For public distribution, use a properly managed release signing key and build a release APK; do not publish a debug build as your production release.
