<?php
// Simple transparent version-check API. Keep this file and update.json on HTTPS hosting.
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');
$manifest = __DIR__ . '/update.json';
if (!is_file($manifest)) {
    http_response_code(503);
    echo json_encode(['error' => 'Update manifest unavailable']);
    exit;
}
readfile($manifest);
