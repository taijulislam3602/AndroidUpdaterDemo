package com.example.updaterdemo

import android.app.Activity
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import android.content.Intent
import android.net.Uri
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import kotlin.concurrent.thread


class MainActivity : Activity() {
    // Replace with your HTTPS-hosted manifest endpoint.
    private val manifestUrl = "https://YOUR-DOMAIN.example/update.json"
    private var officialUpdatePage: String? = null


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        val status = findViewById<TextView>(R.id.status)
        val notes = findViewById<TextView>(R.id.notes)
        val check = findViewById<Button>(R.id.checkButton)
        val open = findViewById<Button>(R.id.openButton)
        val current = findViewById<TextView>(R.id.currentVersion)
        current.text = "Installed version: ${BuildConfig.VERSION_NAME} (${BuildConfig.VERSION_CODE})"

        check.setOnClickListener {
            check.isEnabled = false
            status.text = "Checking update…"
            notes.text = ""
            thread {
                try {
                    val connection = (URL(manifestUrl).openConnection() as HttpURLConnection).apply {
                        connectTimeout = 8000
                        readTimeout = 8000
                        requestMethod = "GET"
                    }
                    val body = connection.inputStream.bufferedReader().use { it.readText() }
                    connection.disconnect()
                    val data = JSONObject(body)
                    val latestCode = data.getInt("versionCode")
                    val latestName = data.getString("versionName")
                    val page = data.getString("updatePageUrl")
                    val releaseNotes = data.optString("releaseNotes", "No release notes supplied.")
                    runOnUiThread {
                        if (latestCode > BuildConfig.VERSION_CODE) {
                            status.text = "Update available: $latestName"
                            notes.text = releaseNotes
                            officialUpdatePage = page
                            open.isEnabled = true
                        } else {
                            status.text = "You are up to date. Latest: $latestName"
                            officialUpdatePage = null
                            open.isEnabled = false
                        }
                        check.isEnabled = true
                    }
                } catch (e: Exception) {
                    runOnUiThread {
                        status.text = "Could not check update. Verify internet and server URL."
                        notes.text = e.localizedMessage ?: "Network error"
                        check.isEnabled = true
                        open.isEnabled = false
                    }
                }
            }
        }
        open.setOnClickListener {
            val page = officialUpdatePage ?: return@setOnClickListener
            try {
                startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(page)))
            } catch (_: Exception) {
                Toast.makeText(this, "No browser found", Toast.LENGTH_SHORT).show()
            }
        }
    }
}
